import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
}

export function Card({ children, className = '', title }: CardProps) {
  return (
    <div className={`bg-card shadow-card border border-border overflow-hidden ${className}`} style={{ borderRadius: 'var(--radius-lg)' }}>
      {title && (
        <div className="px-6 py-4 border-b border-border">
          <h3 className="font-semibold text-foreground" style={{ fontSize: 'var(--text-h3)', lineHeight: 'var(--leading-h3)' }}>{title}</h3>
        </div>
      )}
      <div className="p-6">
        {children}
      </div>
    </div>
  );
}